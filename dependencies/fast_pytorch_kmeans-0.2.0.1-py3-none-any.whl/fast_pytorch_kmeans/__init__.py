from fast_pytorch_kmeans.kmeans import KMeans
from fast_pytorch_kmeans.multi_kmeans import MultiKMeans
