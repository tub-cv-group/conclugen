DOCKER = "docker_env"
PYTHON = "python_env"
CONDA = "conda_env"
ALL = [DOCKER, PYTHON, CONDA]
