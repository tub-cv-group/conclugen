raw={}
raw["words"]='http://immortal.multicomp.cs.cmu.edu/POM/language/POM_TimestampedWords.csd'
raw["phonemes"]='http://immortal.multicomp.cs.cmu.edu/POM/language/POM_TimestampedPhones.csd'


highlevel={}
highlevel["glove_vectors"]='http://immortal.multicomp.cs.cmu.edu/POM/language/POM_TimestampedWordVectors.csd'
highlevel["FACET 4.2"]='http://immortal.multicomp.cs.cmu.edu/POM/visual/POM_Facet_42.csd'
highlevel["OpenFace"]='http://immortal.multicomp.cs.cmu.edu/POM/visual/POM_OpenFace2.csd'
highlevel["COVAREP"]='http://immortal.multicomp.cs.cmu.edu/POM/acoustic/POM_COVAREP.csd'


labels={}
labels["labels"]="http://immortal.multicomp.cs.cmu.edu/POM/labels/POM_Labels.csd"
